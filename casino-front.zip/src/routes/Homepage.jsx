import React from 'react';
import '../static/css/homepage_style.css';
const Homepage = () => {
  return (
    <div className='Homepage'>
      <div >
        <h1 id='title'>Casino</h1>
        <h2 id='subtitle'>Online</h2>
      </div>
      <p id='description'>Welcome to the exciting world of our online casino! <br /><br /> We are a premier entertainment destination, offering a wide range of thrilling games, enticing bonuses, and a secure and reliable gaming experience. Our casino combines elegance and luxury with the most advanced technology to provide you with a unique experience. Join us and dive into the limitless excitement of our online casino. <br /><br />Get ready to experience unforgettable moments and win big prizes with every spin and bet!


      </p>
      <br />
      <br />
      <h2 id='temptation'>Join now!</h2>
      <p id='description2'>All your favourite games</p>
      <h2 id='games'>ROULETTE // SLOT // BLACKJACK</h2>
    </div>
  );
};

export default Homepage;