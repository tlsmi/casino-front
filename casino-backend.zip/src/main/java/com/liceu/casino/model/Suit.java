package com.liceu.casino.model;

public enum Suit {
    PICAS,
    DIAMANTES,
    CORAZONES,
    TREBOLES
}
