package com.liceu.casino.model;

public class BetRequest {
    private int apuesta;

    public int getApuesta() {
        return apuesta;
    }

    public void setApuesta(int apuesta) {
        this.apuesta = apuesta;
    }
}
